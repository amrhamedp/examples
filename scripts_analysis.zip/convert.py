import MDAnalysis


u = MDAnalysis.Universe('prot_dummy.prmtop','prot_dummy.inpcrd')
protein = u.select_atoms("protein")
protein.write("prot_dummy_prot.pdb")
