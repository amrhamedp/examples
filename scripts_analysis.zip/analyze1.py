#script to analyze certain covar and plot it

import os
import matplotlib.pyplot as plt
import math
file_covar_location='/home/cresset/Downloads/msm/adaptive_msm_docker/5tim_systems/5tim_cosolv/generators/0'
file_covar_location='/home/cresset/Downloads/msm/adaptive_msm_docker/5tim_systems/5tim_cosolv_1M/5tim_cos_1M/generators/0'

file_covar_name='phi212.dat'

os.chdir(file_covar_location)
file_covar=open(file_covar_name,'r')
X=[]
Y=[]
for line in file_covar:
    #print (line)
    line_s=line.split()
    x=float(line_s[0])
    y=float(line_s[1])
    y=math.degrees(y)
    if y<0:
        y=360+y
    #print(y)
    X.append(x)
    Y.append(y)

fig, ax = plt.subplots()
ax.plot(X, Y)

ax.set(xlabel='Time (frames)', ylabel='Phi212 ',
       title='Phi212 cosolvent 1M')
ax.grid()

fig.savefig("phi212_cosolvent_1M.png")
plt.show()