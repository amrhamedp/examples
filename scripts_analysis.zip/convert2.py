import MDAnalysis


u = MDAnalysis.Universe('prot_dummy.prmtop','traj.xtc')
protein = u.select_atoms("protein")
with MDAnalysis.Writer("protein.xtc", protein.n_atoms) as W:
    for ts in u.trajectory:
        W.write(protein)
