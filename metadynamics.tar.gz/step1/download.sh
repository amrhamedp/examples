wget https://www.ks.uiuc.edu/Research/vmd/script_library/scripts/orient/orient.tar.gz
tar -xzvf orient.tar.gz
wget https://www.ks.uiuc.edu/Research/vmd/script_library/scripts/orient/la101psx.tar.gz
tar -xzvf la101psx.tar.gz
